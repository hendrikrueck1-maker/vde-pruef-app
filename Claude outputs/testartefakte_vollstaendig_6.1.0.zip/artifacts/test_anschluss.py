#!/usr/bin/env python3
"""Test Anschlussprüfung Übergabepunkt - Leerformular + vollständig + Edge Cases."""
import os, json, glob
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8899"
OUT = "/home/claude/vde-test/artifacts"

def find_chromium():
    c = glob.glob("/opt/pw-browsers/chromium*/**/chrome", recursive=True)
    return c[0] if c else None

def log(msg): print(f"[test_anschluss] {msg}")

def run():
    exe = find_chromium()
    console_errors = []
    dialogs_seen = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=exe, headless=True)
        context = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: console_errors.append(("pageerror", str(exc))))
        def handle_dialog(d):
            dialogs_seen.append((d.type, d.message[:300]))
            log(f"DIALOG [{d.type}]: {d.message[:200]}")
            d.accept()
        page.on("dialog", handle_dialog)

        def fill(id_, val):
            el = page.locator(f"#{id_}")
            if el.count(): el.fill(str(val))

        # -------- 1. Leerformular --------
        page.goto(f"{BASE}/anschlusspruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        with page.expect_download() as dl_info:
            page.click("text=Leeres Protokoll drucken")
        dl_info.value.save_as(os.path.join(OUT, "anschluss_leerformular.pdf"))
        log("Leerformular gespeichert")

        # -------- 2. Vollständig --------
        page.goto(f"{BASE}/anschlusspruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        fill("auftraggeber", "Stadthalle Musterstadt")
        fill("veranstaltung", "Freilichtkonzert Marktplatz")
        fill("pruefungsnummer", "AP-TEST-001")
        fill("pruefer", "Erika Musterfrau")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")
        fill("messgeraet", "Installationstester Fluke 1663")
        fill("seriennummer", "TEST-SN-002")
        fill("vnb", "Stadtwerke Musterstadt")
        fill("bereitsteller_ansprechpartner", "Herr Beispiel")
        fill("bereitsteller_telefon", "0123-456789")
        page.select_option("#einspeisung_art", index=1)
        fill("uebergabe_standort", "Zählerschrank Bühneneingang")
        fill("anschlussleistung_vertrag", "63")

        fill("u_l1n", "231")
        fill("u_l2n", "229")
        fill("u_l3n", "230")
        fill("u_l12", "400")
        fill("u_l23", "401")
        fill("u_l13", "399")
        fill("netzfrequenz", "50")

        # Sichtprüfung
        for sid_loc in page.locator(".sicht-item").all():
            try:
                sid_loc.select_option(label="i.O.")
            except Exception:
                pass

        page.select_option("#pa_angeschlossen", label="Ja")
        fill("erdung_re", "0,25")
        fill("pa_messpunkt", "PA-Schiene im Übergabeverteiler")

        page.click("text=+ Übergabepunkt hinzufügen")
        page.wait_for_timeout(200)
        cards = page.locator("#feedsContainer > *")
        n = cards.count()
        log(f"Anzahl Übergabepunkt-Karten: {n}")
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", f"Übergabepunkt {i+1}")
            nsel = card.locator(".c-netzsystem")
            if nsel.count(): nsel.first.select_option(index=1)
            cfill(".c-spannung", "230 / 400")
            cfill(".c-rpe", "0,15")
            cfill(".c-unpe", "0,3")
            cfill(".c-sich-typ", "C 32A")
            cfill(".c-zs", "0,30")
            cfill(".c-rcd-typ", "Typ A")
            cfill(".c-rcd-idn", "30 mA")
            psel = card.locator(".c-rcd-pruefstrom")
            if psel.count(): psel.first.select_option(index=1)
            cfill(".c-rcd-imess", "18")
            tasel = card.locator(".c-rcd-ta")
            if tasel.count(): tasel.first.fill("22")

        page.wait_for_timeout(300)
        page.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page.select_option("#res_leistung_ausreichend", label="Ja")
        page.select_option("#res_freigabe", index=0)
        fill("unterschrift_ort", "Musterstadt")
        fill("unterschrift_datum", "2026-09-04")

        for canvas_id in ["sigUebergeber", "sigUebernehmer"]:
            box = page.locator(f"#{canvas_id}").bounding_box()
            if box:
                x0, y0 = box["x"]+10, box["y"]+box["height"]/2
                page.mouse.move(x0, y0)
                page.mouse.down()
                for dx in range(0, 100, 10):
                    page.mouse.move(x0+dx, y0 + (10 if dx%20==0 else -10))
                page.mouse.up()

        page.wait_for_timeout(300)
        page.screenshot(path=os.path.join(OUT, "anschluss_filled_screenshot.png"), full_page=True)

        try:
            with page.expect_download(timeout=10000) as dl_info2:
                page.click("text=Ausgefülltes PDF generieren")
            dl_info2.value.save_as(os.path.join(OUT, "anschluss_vollstaendig.pdf"))
            log("Vollständiges PDF gespeichert")
        except Exception as e:
            log(f"FEHLER: {e}")
            page.screenshot(path=os.path.join(OUT, "anschluss_vollstaendig_FAILED.png"), full_page=True)

        # -------- 3. Edge cases --------
        page.goto(f"{BASE}/anschlusspruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        xss = '<script>alert(1)</script>"><img src=x onerror=alert(2)>'
        fill("auftraggeber", xss)
        fill("veranstaltung", "A"*400)
        fill("pruefer", "Test <b>X</b>")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")
        page.select_option("#einspeisung_art", index=0)
        fill("uebergabe_standort", xss)
        fill("erdung_re", "-3")
        for sid_loc in page.locator(".sicht-item").all():
            try: sid_loc.select_option(label="i.O.")
            except Exception: pass
        page.select_option("#pa_angeschlossen", label="Ja")

        cards = page.locator("#feedsContainer > *")
        n = cards.count()
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", xss)
            cfill(".c-rpe", "1,2,3")
            cfill(".c-unpe", "0,3")
            cfill(".c-zs", "-9,9")
            cfill(".c-sich-typ", "C 32A")
        page.select_option("#res_maengel", label="Mängel festgestellt (siehe Bemerkung)")
        page.select_option("#res_freigabe", label="Nein (Sicherheitsrisiko)")
        fill("res_bemerkungen", xss)
        page.wait_for_timeout(300)
        page.screenshot(path=os.path.join(OUT, "anschluss_edgecases_screenshot.png"), full_page=True)
        try:
            with page.expect_download(timeout=8000) as dl_info3:
                page.click("text=Ausgefülltes PDF generieren")
            dl_info3.value.save_as(os.path.join(OUT, "anschluss_edgecases.pdf"))
            log("Edge-case PDF gespeichert")
        except Exception as e:
            log(f"Edge-case PDF NICHT erzeugt: {e}")
            page.screenshot(path=os.path.join(OUT, "anschluss_edgecases_blocked.png"), full_page=True)

        log(f"Dialoge: {dialogs_seen}")
        log(f"Console errors: {json.dumps(console_errors, ensure_ascii=False)}")
        with open(os.path.join(OUT, "anschluss_console_errors.json"), "w") as f:
            json.dump(console_errors, f, ensure_ascii=False, indent=2)
        browser.close()

if __name__ == "__main__":
    run()
