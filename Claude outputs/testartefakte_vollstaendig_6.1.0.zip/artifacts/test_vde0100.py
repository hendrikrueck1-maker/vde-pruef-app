#!/usr/bin/env python3
"""Test VDE0100 (Anlagenprüfung) - Leerformular + vollständig + Edge Cases."""
import sys, os, time, json
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8899"
OUT = "/home/claude/vde-test/artifacts"
CHROMIUM = "/opt/pw-browsers/chromium/chrome-linux/chrome"

def find_chromium():
    import glob
    cands = glob.glob("/opt/pw-browsers/chromium*/**/chrome", recursive=True) + \
            glob.glob("/opt/pw-browsers/chromium*/**/headless_shell", recursive=True)
    return cands[0] if cands else None

def log(msg):
    print(f"[test_vde0100] {msg}")

def run():
    exe = find_chromium()
    log(f"Using chromium: {exe}")
    console_errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=exe, headless=True)
        context = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: console_errors.append(("pageerror", str(exc))))
        dialogs_seen = []
        def handle_dialog(d):
            dialogs_seen.append((d.type, d.message[:300]))
            log(f"DIALOG [{d.type}]: {d.message[:300]}")
            d.accept()
        page.on("dialog", handle_dialog)

        # -------- 1. Leerformular PDF --------
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        with page.expect_download() as dl_info:
            page.click("text=Leeres Protokoll drucken")
        dl = dl_info.value
        path1 = os.path.join(OUT, "vde0100_leerformular.pdf")
        dl.save_as(path1)
        log(f"Leerformular PDF gespeichert: {path1}")

        # -------- 2. Vollständig ausgefülltes Formular --------
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(500)

        def fill(id_, val):
            el = page.locator(f"#{id_}")
            if el.count():
                el.fill(str(val))

        fill("auftraggeber", "Stadthalle Musterstadt, Teststraße 1, 12345 Musterstadt")
        fill("anlage_bez", "Hauptverteilung Bühne, UV-1")
        fill("pruefungsnummer", "PR-TEST-001")
        fill("pruefer", "Erika Musterfrau")
        page.select_option("#pruefer_qualifikation", label="Elektrofachkraft (EFK)")
        fill("datum", "2026-09-04")
        fill("hausanschluss", "NH 3x100A gL - HAK Keller")
        page.select_option("#pruefnorm", index=1)
        page.select_option("#pruefgrund", index=1)
        page.select_option("#netzsystem", index=1)
        fill("netzspannung", "230 / 400")
        page.select_option("#einspeisung", index=1)
        fill("vnb", "Stadtwerke Musterstadt")
        fill("messgeraet", "Installationstester Fluke 1663")
        fill("seriennummer", "TEST-SN-0001")

        # Netzmessung
        fill("u_l1n", "231")
        fill("u_l2n", "229")
        fill("u_l3n", "230")
        fill("u_l12", "400")
        fill("u_l23", "401")
        fill("u_l13", "399")
        fill("u_npe", "0,3")
        fill("netzfrequenz", "50")

        # Sichtprüfung - alle auf i.O. außer einer n.i.O. testen
        sicht_ids = ["sicht_betriebsmittel","sicht_kabel","sicht_zugang","sicht_schaltgeraete",
                     "sicht_kennzeichnung","sicht_doku","sicht_pa","sicht_basisschutz",
                     "sicht_typenschild","sicht_brandschott","sicht_leiterverb","sicht_gst"]
        for sid in sicht_ids:
            page.select_option(f"#{sid}", label="i.O.")

        fill("anschluss_typ", "H07RN-F")
        fill("anschluss_leiter", "5G")
        fill("anschluss_qs", "16 mm²")

        for eid in ["erp_anlage","erp_schutz"]:
            page.select_option(f"#{eid}", label="i.O.")

        # Erdung
        fill("erdung_re", "0,25")
        fill("erdung_messpunkt", "HES Keller")

        # Stromkreise: es gibt bereits 2 Karten default. Fill both + add a 3rd.
        page.click("text=+ Stromkreis hinzufügen")
        page.wait_for_timeout(200)

        cards = page.locator("#circuitsContainer > *")
        n = cards.count()
        log(f"Anzahl Stromkreis-Karten: {n}")
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count():
                    loc.first.fill(str(val))
            cfill(".c-bez", f"Stromkreis {i+1} - Testverbraucher")
            cfill(".c-rpe", "0,15")
            cfill(".c-riso", "> 500")
            cfill(".c-sich-typ", "B 16A")
            cfill(".c-zs", "0,35")
            page.wait_for_timeout(50)
            cfill(".c-rcd-typ", "Typ A")
            cfill(".c-rcd-idn", "30 mA")
            rcd_pruefstrom_sel = card.locator(".c-rcd-pruefstrom")
            if rcd_pruefstrom_sel.count():
                rcd_pruefstrom_sel.first.select_option(index=1)
            cfill(".c-rcd-imess", "18")
            rcd_ta_sel = card.locator(".c-rcd-ta, [id^='rcd_ta_']")
            if rcd_ta_sel.count():
                rcd_ta_sel.first.fill("22")

        page.wait_for_timeout(300)

        page.select_option("#pruefumfang", index=0)
        page.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page.select_option("#res_plakette", label="Ja")
        fill("res_termin_date", "2028-09")
        page.select_option("#res_gewaehrleistung", label="Ja (Anlage entspricht VDE-Regeln)")
        fill("unterschrift_ort", "Musterstadt")
        fill("unterschrift_datum", "2026-09-04")

        # Signature pads: draw a simple signature via mouse events
        for canvas_id in ["sigPruefer", "sigKunde"]:
            box = page.locator(f"#{canvas_id}").bounding_box()
            if box:
                x0, y0 = box["x"]+10, box["y"]+box["height"]/2
                page.mouse.move(x0, y0)
                page.mouse.down()
                for dx in range(0, 100, 10):
                    page.mouse.move(x0+dx, y0 + (10 if dx%20==0 else -10))
                page.mouse.up()

        page.wait_for_timeout(300)
        page.screenshot(path=os.path.join(OUT, "vde0100_filled_screenshot.png"), full_page=True)

        try:
            with page.expect_download(timeout=10000) as dl_info2:
                page.click("text=Ausgefülltes PDF generieren")
            dl2 = dl_info2.value
            path2 = os.path.join(OUT, "vde0100_vollstaendig.pdf")
            dl2.save_as(path2)
            log(f"Vollständiges PDF gespeichert: {path2}")
        except Exception as e:
            log(f"FEHLER beim Erzeugen des vollständigen PDF: {e}")
            page.screenshot(path=os.path.join(OUT, "vde0100_vollstaendig_FAILED.png"), full_page=True)

        # -------- 3. Edge Cases: XSS, lange Texte, Kommazahlen, negative Werte --------
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        xss_payload = '<script>alert(1)</script>"><img src=x onerror=alert(2)>'
        long_text = "A" * 500 + " Ende"
        fill("auftraggeber", xss_payload)
        fill("anlage_bez", long_text)
        fill("pruefer", "Test <b>Bold</b> & \"Quotes\" 'Apos'")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")
        fill("hausanschluss", xss_payload)
        page.select_option("#pruefnorm", index=0)
        page.select_option("#pruefgrund", index=0)
        page.select_option("#netzsystem", index=0)
        page.select_option("#einspeisung", index=0)
        fill("erdung_re", "-5")  # negative Wert
        fill("netzspannung", "3x400")

        sicht_ids2 = ["sicht_betriebsmittel","sicht_kabel","sicht_zugang","sicht_schaltgeraete",
                     "sicht_kennzeichnung","sicht_doku","sicht_pa","sicht_basisschutz",
                     "sicht_typenschild","sicht_brandschott","sicht_leiterverb","sicht_gst"]
        for sid in sicht_ids2:
            page.select_option(f"#{sid}", label="i.O.")
        for eid in ["erp_anlage","erp_schutz"]:
            page.select_option(f"#{eid}", label="i.O.")

        cards = page.locator("#circuitsContainer > *")
        n = cards.count()
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count():
                    loc.first.fill(str(val))
            cfill(".c-bez", xss_payload)
            cfill(".c-rpe", "1,2,3")  # doppeltes Komma - Bug #4 Test
            cfill(".c-zs", "-2,5")  # negativ
            cfill(".c-sich-typ", "B 16A")

        page.wait_for_timeout(300)
        page.select_option("#pruefumfang", index=0)
        page.select_option("#res_maengel", label="Mängel festgestellt (siehe Bemerkung)")
        page.select_option("#res_plakette", label="Nein")
        page.select_option("#res_gewaehrleistung", label="Nein (Sicherheitsrisiko)")
        fill("res_bemerkungen", xss_payload + " " + long_text)
        fill("unterschrift_ort", xss_payload)
        fill("unterschrift_datum", "2026-09-04")

        # Check .out-of-norm markings present for negative erdung_re
        erdung_class = page.locator("#erdung_re").get_attribute("class")
        log(f"erdung_re class nach -5 Eingabe: {erdung_class}")

        # Netzspannung "3x400" check - should remain unmangled per changelog
        netzspannung_val = page.locator("#netzspannung").input_value()
        log(f"netzspannung nach '3x400' Eingabe: '{netzspannung_val}'")

        page.screenshot(path=os.path.join(OUT, "vde0100_edgecases_screenshot.png"), full_page=True)

        # Try generating PDF with these edge-case / invalid values
        try:
            with page.expect_download(timeout=5000) as dl_info3:
                page.click("text=Ausgefülltes PDF generieren")
            dl3 = dl_info3.value
            path3 = os.path.join(OUT, "vde0100_edgecases.pdf")
            dl3.save_as(path3)
            log(f"Edge-case PDF gespeichert: {path3}")
        except Exception as e:
            log(f"Edge-case PDF NICHT erzeugt (evtl. durch Validierung blockiert): {e}")
            page.screenshot(path=os.path.join(OUT, "vde0100_edgecases_blocked.png"), full_page=True)

        log(f"Alle Dialoge waehrend des Laufs: {dialogs_seen}")
        log(f"Console errors: {json.dumps(console_errors, ensure_ascii=False, indent=2)}")

        with open(os.path.join(OUT, "vde0100_console_errors.json"), "w") as f:
            json.dump(console_errors, f, ensure_ascii=False, indent=2)

        browser.close()

if __name__ == "__main__":
    run()
