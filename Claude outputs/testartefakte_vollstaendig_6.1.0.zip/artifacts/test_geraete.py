#!/usr/bin/env python3
"""Test Geräteprüfung - Leerformular + vollständig + Edge Cases + Sichtprüfung-Default-Test."""
import os, json, glob
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8899"
OUT = "/home/claude/vde-test/artifacts"

def find_chromium():
    c = glob.glob("/opt/pw-browsers/chromium*/**/chrome", recursive=True)
    return c[0] if c else None

def log(msg): print(f"[test_geraete] {msg}")

def run():
    exe = find_chromium()
    console_errors = []
    dialogs_seen = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=exe, headless=True)
        context = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: console_errors.append(("pageerror", str(exc))))
        def handle_dialog(d):
            dialogs_seen.append((d.type, d.message[:300]))
            log(f"DIALOG [{d.type}]: {d.message[:200]}")
            d.accept()
        page.on("dialog", handle_dialog)

        def fill(id_, val):
            el = page.locator(f"#{id_}")
            if el.count(): el.fill(str(val))

        # -------- 1. Leerformular --------
        page.goto(f"{BASE}/geraetepruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        with page.expect_download() as dl_info:
            page.click("text=Leeres Protokoll drucken")
        dl_info.value.save_as(os.path.join(OUT, "geraete_leerformular.pdf"))
        log("Leerformular gespeichert")

        # -------- 2. SICHTPRÜFUNG-DEFAULT-TEST: Nur Messwerte ausfüllen, ---------
        # -------- Sichtprüfung/Funktion NICHT anfassen -> zeigt "i.O." unreviewed? --------
        page.goto(f"{BASE}/geraetepruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        fill("auftraggeber", "Test GmbH")
        fill("pruefer", "Test Pruefer")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")
        fill("messgeraet", "Fluke 1663")
        fill("seriennummer", "SN-001")

        cards = page.locator("#devicesContainer > *")
        n = cards.count()
        log(f"Anzahl Geräte-Karten (Default): {n}")
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", f"Gerät {i+1} UNREVIEWED-SICHTPRUEFUNG")
            cfill(".c-typ", "Testgerät")
            cfill(".c-invnr", f"INV-{i+1}")
            sksel = card.locator(".c-schutzklasse")
            if sksel.count(): sksel.first.select_option(value="I")
            cfill(".c-rpe", "0,20")
            cfill(".c-riso", "> 100")
            cfill(".c-ableitstrom", "0,3")
            # BEWUSST NICHT ANGEFASST: .c-sicht-item (4x) und .c-funktion (1x)
            # -> testet ob Browser-Default "i.O." unbemerkt durchgeht

        # dump values of untouched selects
        sicht_vals = page.eval_on_selector_all(".c-sicht-item", "els => els.map(e => e.value)")
        funktion_vals = page.eval_on_selector_all(".c-funktion", "els => els.map(e => e.value)")
        log(f"c-sicht-item Werte (NICHT angefasst): {sicht_vals}")
        log(f"c-funktion Werte (NICHT angefasst): {funktion_vals}")

        page.select_option("#pruefumfang", index=0)
        page.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page.select_option("#res_plakette", label="Ja")
        page.select_option("#res_gewaehrleistung", value="Ja")
        fill("unterschrift_ort", "Musterstadt")
        fill("unterschrift_datum", "2026-09-04")
        for canvas_id in ["sigPruefer", "sigKunde"]:
            box = page.locator(f"#{canvas_id}").bounding_box()
            if box:
                x0, y0 = box["x"]+10, box["y"]+box["height"]/2
                page.mouse.move(x0, y0); page.mouse.down()
                for dx in range(0, 100, 10):
                    page.mouse.move(x0+dx, y0 + (10 if dx%20==0 else -10))
                page.mouse.up()
        page.wait_for_timeout(300)

        try:
            with page.expect_download(timeout=8000) as dl_info_default:
                page.click("text=Ausgefülltes PDF generieren")
            dl_info_default.value.save_as(os.path.join(OUT, "geraete_UNREVIEWED_sichtpruefung_TEST.pdf"))
            log("!!! WICHTIG: PDF WURDE ERZEUGT OBWOHL SICHTPRUEFUNG/FUNKTION NIE ANGEFASST WURDE !!!")
        except Exception as e:
            log(f"PDF NICHT erzeugt (App hat blockiert - das waere das SICHERE Verhalten): {e}")

        # -------- 3. Vollständig (bewusst korrekt ausgefüllt) --------
        page.goto(f"{BASE}/geraetepruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        fill("auftraggeber", "Stadthalle Musterstadt")
        page.select_option("#pruefart", index=1)
        page.select_option("#pruefintervall", index=1)
        fill("pruefungsnummer", "GP-TEST-001")
        fill("pruefer", "Erika Musterfrau")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")
        fill("messgeraet", "Installationstester Fluke 1663")
        fill("seriennummer", "TEST-SN-003")

        page.click("text=+ Gerät hinzufügen")
        page.wait_for_timeout(200)
        cards = page.locator("#devicesContainer > *")
        n = cards.count()
        log(f"Anzahl Geräte-Karten (vollständig): {n}")
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", f"Gerät {i+1} - Scheinwerfer")
            cfill(".c-typ", "ADB PAR64")
            cfill(".c-invnr", f"INV-{i+1}00")
            sksel = card.locator(".c-schutzklasse")
            if sksel.count(): sksel.first.select_option(value="I")
            cfill(".c-laenge", "10")
            for sel_loc in card.locator(".c-sicht-item").all():
                sel_loc.select_option(label="i.O.")
            funksel = card.locator(".c-funktion")
            if funksel.count(): funksel.first.select_option(label="i.O.")
            cfill(".c-rpe", "0,20")
            cfill(".c-riso", "> 100")
            cfill(".c-ableitstrom", "0,3")

        page.wait_for_timeout(300)
        page.select_option("#pruefumfang", index=0)
        page.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page.select_option("#res_plakette", label="Ja")
        page.select_option("#res_gewaehrleistung", value="Ja")
        fill("unterschrift_ort", "Musterstadt")
        fill("unterschrift_datum", "2026-09-04")
        for canvas_id in ["sigPruefer", "sigKunde"]:
            box = page.locator(f"#{canvas_id}").bounding_box()
            if box:
                x0, y0 = box["x"]+10, box["y"]+box["height"]/2
                page.mouse.move(x0, y0); page.mouse.down()
                for dx in range(0, 100, 10):
                    page.mouse.move(x0+dx, y0 + (10 if dx%20==0 else -10))
                page.mouse.up()
        page.wait_for_timeout(300)
        page.screenshot(path=os.path.join(OUT, "geraete_filled_screenshot.png"), full_page=True)

        try:
            with page.expect_download(timeout=10000) as dl_info2:
                page.click("text=Ausgefülltes PDF generieren")
            dl_info2.value.save_as(os.path.join(OUT, "geraete_vollstaendig.pdf"))
            log("Vollständiges PDF gespeichert")
        except Exception as e:
            log(f"FEHLER: {e}")
            page.screenshot(path=os.path.join(OUT, "geraete_vollstaendig_FAILED.png"), full_page=True)

        # -------- 4. Edge cases --------
        page.goto(f"{BASE}/geraetepruefung.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        xss = '<script>alert(1)</script>"><img src=x onerror=alert(2)>'
        fill("auftraggeber", xss)
        page.select_option("#pruefart", index=0)
        page.select_option("#pruefintervall", index=0)
        fill("pruefer", "Test <b>X</b>")
        page.select_option("#pruefer_qualifikation", index=1)
        fill("datum", "2026-09-04")

        cards = page.locator("#devicesContainer > *")
        n = cards.count()
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", xss)
            cfill(".c-typ", "A"*300)
            sksel = card.locator(".c-schutzklasse")
            if sksel.count(): sksel.first.select_option(value="I")
            for sel_loc in card.locator(".c-sicht-item").all():
                sel_loc.select_option(label="n.i.O.")
            funksel = card.locator(".c-funktion")
            if funksel.count(): funksel.first.select_option(label="n.i.O.")
            cfill(".c-rpe", "1,2,3")
            cfill(".c-riso", "-5")
            cfill(".c-ableitstrom", "-1")

        page.wait_for_timeout(300)
        page.select_option("#res_maengel", label="Mängel festgestellt (siehe Bemerkung)")
        page.select_option("#res_plakette", label="Nein")
        page.select_option("#res_gewaehrleistung", label="Nein (Sicherheitsrisiko)")
        fill("res_bemerkungen", xss)
        page.wait_for_timeout(300)
        page.screenshot(path=os.path.join(OUT, "geraete_edgecases_screenshot.png"), full_page=True)
        try:
            with page.expect_download(timeout=8000) as dl_info3:
                page.click("text=Ausgefülltes PDF generieren")
            dl_info3.value.save_as(os.path.join(OUT, "geraete_edgecases.pdf"))
            log("Edge-case PDF gespeichert")
        except Exception as e:
            log(f"Edge-case PDF NICHT erzeugt: {e}")
            page.screenshot(path=os.path.join(OUT, "geraete_edgecases_blocked.png"), full_page=True)

        log(f"Dialoge: {dialogs_seen}")
        log(f"Console errors: {json.dumps(console_errors, ensure_ascii=False)}")
        with open(os.path.join(OUT, "geraete_console_errors.json"), "w") as f:
            json.dump(console_errors, f, ensure_ascii=False, indent=2)
        browser.close()

if __name__ == "__main__":
    run()
