#!/usr/bin/env python3
"""Test Offline-Modus, Mehrfach-/Serien-Simulation (viele Stromkreise), Tablet-Viewport, localStorage-Quota."""
import os, json, glob
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8899"
OUT = "/home/claude/vde-test/artifacts"

def find_chromium():
    c = glob.glob("/opt/pw-browsers/chromium*/**/chrome", recursive=True)
    return c[0] if c else None

def log(msg): print(f"[test_offline_stress] {msg}")

def run():
    exe = find_chromium()
    console_errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=exe, headless=True)

        # ============ TEIL A: Service Worker cachen (online), dann offline testen ============
        context = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page.on("dialog", lambda d: d.accept())

        # Erstmal online besuchen, damit SW installiert + Precache läuft
        for path in ["index.html", "vde0100.html", "anschlusspruefung.html", "geraetepruefung.html", "archiv.html"]:
            page.goto(f"{BASE}/{path}", wait_until="networkidle")
            page.wait_for_timeout(300)

        # SW-Registrierung/Aktivierung abwarten
        page.wait_for_timeout(1500)
        sw_state = page.evaluate("""async () => {
            if (!navigator.serviceWorker) return 'not supported';
            const reg = await navigator.serviceWorker.getRegistration();
            return reg ? { active: !!reg.active, scope: reg.scope } : 'no registration';
        }""")
        log(f"Service Worker Status: {sw_state}")

        # Jetzt offline schalten
        context.set_offline(True)
        log("Kontext auf OFFLINE gesetzt")

        def fill(id_, val):
            el = page.locator(f"#{id_}")
            if el.count(): el.fill(str(val))

        offline_results = {}
        for name, path in [("VDE0100", "vde0100.html"), ("Anschluss", "anschlusspruefung.html"), ("Geraete", "geraetepruefung.html")]:
            try:
                page.goto(f"{BASE}/{path}", wait_until="load", timeout=10000)
                page.wait_for_timeout(500)
                title = page.title()
                offline_results[name] = f"OK geladen, Titel: {title}"
                page.screenshot(path=os.path.join(OUT, f"offline_{name}_screenshot.png"))
            except Exception as e:
                offline_results[name] = f"FEHLER: {e}"
        log(f"Offline-Laden-Ergebnisse: {json.dumps(offline_results, ensure_ascii=False, indent=2)}")

        # Versuche offline ein PDF zu erzeugen (VDE0100 Leerformular)
        try:
            page.goto(f"{BASE}/vde0100.html", wait_until="load", timeout=10000)
            page.wait_for_timeout(500)
            with page.expect_download(timeout=8000) as dlw:
                page.click("text=Leeres Protokoll drucken")
            dlw.value.save_as(os.path.join(OUT, "offline_leerformular_test.pdf"))
            log("OFFLINE PDF-Erzeugung: ERFOLGREICH")
        except Exception as e:
            log(f"OFFLINE PDF-Erzeugung FEHLGESCHLAGEN: {e}")
            page.screenshot(path=os.path.join(OUT, "offline_pdf_failed.png"))

        context.set_offline(False)
        page.close()
        context.close()
        log("Zurück online geschaltet")

        # ============ TEIL B: Mehrfach-/Serien-Simulation (viele Stromkreise) ============
        context2 = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page2 = context2.new_page()
        page2.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page2.on("dialog", lambda d: d.accept())

        page2.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page2.wait_for_timeout(300)
        page2.locator("#auftraggeber").fill("OpenAir Grossveranstaltung Stress-Test")
        page2.locator("#anlage_bez").fill("Hauptverteilung mit vielen Unterverteilungen")
        page2.locator("#pruefer").fill("Stress Tester")
        page2.select_option("#pruefer_qualifikation", index=1)
        page2.locator("#datum").fill("2026-09-04")
        for sid in ["sicht_betriebsmittel","sicht_kabel","sicht_zugang","sicht_schaltgeraete",
                    "sicht_kennzeichnung","sicht_doku","sicht_pa","sicht_basisschutz",
                    "sicht_typenschild","sicht_brandschott","sicht_leiterverb","sicht_gst"]:
            page2.select_option(f"#{sid}", label="i.O.")
        for eid in ["erp_anlage","erp_schutz"]:
            page2.select_option(f"#{eid}", label="i.O.")
        page2.locator("#erdung_re").fill("0,2")

        # 40 Stromkreise hinzufügen (typisch für grosse OpenAir-Verteilung)
        N_CIRCUITS = 40
        for _ in range(N_CIRCUITS - 2):  # 2 bereits vorhanden
            page2.click("text=+ Stromkreis hinzufügen")
        page2.wait_for_timeout(500)
        cards = page2.locator("#circuitsContainer > *")
        n = cards.count()
        log(f"STRESS-TEST: {n} Stromkreis-Karten angelegt")

        import time
        t0 = time.time()
        for i in range(n):
            card = cards.nth(i)
            def cfill(sel, val):
                loc = card.locator(sel)
                if loc.count(): loc.first.fill(str(val))
            cfill(".c-bez", f"Stromkreis {i+1} - Verbraucher Bühne/Zelt {i+1}")
            cfill(".c-rpe", f"0,{10+i%20:02d}")
            cfill(".c-riso", "> 500")
            cfill(".c-sich-typ", "B 16A" if i % 3 else "C 16A")
            cfill(".c-zs", "0,35")
            cfill(".c-rcd-typ", "Typ A")
            cfill(".c-rcd-idn", "30 mA")
            psel = card.locator(".c-rcd-pruefstrom")
            if psel.count(): psel.first.select_option(index=1)
            cfill(".c-rcd-imess", "18")
            tasel = card.locator(".c-rcd-ta")
            if tasel.count(): tasel.first.fill("22")
        t1 = time.time()
        log(f"STRESS-TEST: Ausfüllzeit für {n} Karten: {t1-t0:.1f}s")

        page2.wait_for_timeout(500)
        page2.select_option("#pruefumfang", index=0)
        page2.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page2.select_option("#res_plakette", label="Ja")
        page2.select_option("#res_gewaehrleistung", value="Ja")
        page2.locator("#unterschrift_ort").fill("Musterstadt")
        page2.locator("#unterschrift_datum").fill("2026-09-04")

        t2 = time.time()
        try:
            with page2.expect_download(timeout=30000) as dlw2:
                page2.click("text=Ausgefülltes PDF generieren")
            dlw2.value.save_as(os.path.join(OUT, f"stress_test_{n}_stromkreise.pdf"))
            t3 = time.time()
            log(f"STRESS-TEST: PDF mit {n} Stromkreisen erzeugt in {t3-t2:.1f}s")
        except Exception as e:
            log(f"STRESS-TEST FEHLER bei PDF-Erzeugung mit {n} Stromkreisen: {e}")
            page2.screenshot(path=os.path.join(OUT, "stress_test_FAILED.png"), full_page=True)

        context2.close()

        # ============ TEIL C: Tablet-Viewport (iPad 820x1180) ============
        context3 = browser.new_context(accept_downloads=True, viewport={"width":820,"height":1180}, has_touch=True)
        page3 = context3.new_page()
        page3.on("dialog", lambda d: d.accept())
        for path, name in [("index.html","Start"), ("vde0100.html","VDE0100"), ("geraetepruefung.html","Geraete")]:
            page3.goto(f"{BASE}/{path}", wait_until="networkidle")
            page3.wait_for_timeout(500)
            page3.screenshot(path=os.path.join(OUT, f"tablet_{name}_screenshot.png"), full_page=True)
        log("Tablet-Viewport Screenshots erstellt (820x1180)")

        # Touch-Test für Signature Pad
        page3.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page3.wait_for_timeout(500)
        canvas = page3.locator("#sigPruefer")
        if canvas.count():
            box = canvas.bounding_box()
            if box:
                x0, y0 = box["x"]+15, box["y"]+box["height"]/2
                page3.touchscreen.tap(x0, y0)
                log("Touch-Tap auf Signature-Pad ausgeführt (kein Fehler = OK)")
        context3.close()

        # ============ TEIL D: leere Unterschrift -> sollte abgelehnt werden ============
        context4 = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page4 = context4.new_page()
        dialogs4 = []
        page4.on("dialog", lambda d: (dialogs4.append(d.message[:200]), d.accept()))
        page4.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page4.wait_for_timeout(300)
        page4.locator("#auftraggeber").fill("Sig-Test Firma")
        page4.locator("#anlage_bez").fill("Sig-Test Anlage")
        page4.locator("#pruefer").fill("Sig Tester")
        page4.select_option("#pruefer_qualifikation", index=1)
        page4.locator("#datum").fill("2026-09-04")
        for sid in ["sicht_betriebsmittel","sicht_kabel","sicht_zugang","sicht_schaltgeraete",
                    "sicht_kennzeichnung","sicht_doku","sicht_pa","sicht_basisschutz",
                    "sicht_typenschild","sicht_brandschott","sicht_leiterverb","sicht_gst"]:
            page4.select_option(f"#{sid}", label="i.O.")
        for eid in ["erp_anlage","erp_schutz"]:
            page4.select_option(f"#{eid}", label="i.O.")
        page4.locator("#erdung_re").fill("0,2")
        cards4 = page4.locator("#circuitsContainer > *")
        for i in range(cards4.count()):
            card = cards4.nth(i)
            card.locator(".c-bez").first.fill(f"SK{i+1}")
            card.locator(".c-rpe").first.fill("0,1")
            card.locator(".c-riso").first.fill("> 500")
            card.locator(".c-sich-typ").first.fill("B 16A")
            card.locator(".c-zs").first.fill("0,3")
        page4.select_option("#res_maengel", label="Keine Mängel festgestellt")
        page4.select_option("#res_plakette", label="Ja")
        page4.select_option("#res_gewaehrleistung", value="Ja")
        # BEWUSST KEINE UNTERSCHRIFT gesetzt
        page4.wait_for_timeout(300)
        try:
            with page4.expect_download(timeout=5000) as dlw4:
                page4.click("text=Ausgefülltes PDF generieren")
            dlw4.value.save_as(os.path.join(OUT, "leere_unterschrift_TEST.pdf"))
            log("!!! PDF WURDE ERZEUGT OHNE JEDE UNTERSCHRIFT !!!")
        except Exception as e:
            log(f"PDF ohne Unterschrift NICHT erzeugt (erwartetes/sicheres Verhalten): {e}")
            log(f"Dialoge dabei: {dialogs4}")
        context4.close()

        log(f"Console errors (gesamt): {json.dumps(console_errors, ensure_ascii=False)}")
        with open(os.path.join(OUT, "offline_stress_console_errors.json"), "w") as f:
            json.dump(console_errors, f, ensure_ascii=False, indent=2)
        browser.close()

if __name__ == "__main__":
    run()
