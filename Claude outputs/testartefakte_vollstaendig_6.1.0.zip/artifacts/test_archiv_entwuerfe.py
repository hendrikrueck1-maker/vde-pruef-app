#!/usr/bin/env python3
"""Test Archiv, Entwürfe/Autosave, URL-Parameter-Manipulation, Protokollnummer-Lücken."""
import os, json, glob
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8899"
OUT = "/home/claude/vde-test/artifacts"

def find_chromium():
    c = glob.glob("/opt/pw-browsers/chromium*/**/chrome", recursive=True)
    return c[0] if c else None

def log(msg): print(f"[test_archiv] {msg}")

def run():
    exe = find_chromium()
    console_errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=exe, headless=True)
        context = browser.new_context(accept_downloads=True, viewport={"width":1280,"height":900})
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append((msg.type, msg.text)) if msg.type == "error" else None)
        page.on("pageerror", lambda exc: console_errors.append(("pageerror", str(exc))))
        page.on("dialog", lambda d: d.accept())

        def fill(id_, val):
            el = page.locator(f"#{id_}")
            if el.count(): el.fill(str(val))

        # ============ TEIL A: Mehrere Protokolle erzeugen fürs Archiv ============
        for idx in range(3):
            page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
            page.wait_for_timeout(300)
            fill("auftraggeber", f"Archiv-Test Firma {idx+1}")
            fill("anlage_bez", f"Testanlage {idx+1}")
            fill("pruefer", "Tester Archiv")
            page.select_option("#pruefer_qualifikation", index=1)
            fill("datum", "2026-09-04")
            for sid in ["sicht_betriebsmittel","sicht_kabel","sicht_zugang","sicht_schaltgeraete",
                        "sicht_kennzeichnung","sicht_doku","sicht_pa","sicht_basisschutz",
                        "sicht_typenschild","sicht_brandschott","sicht_leiterverb","sicht_gst"]:
                page.select_option(f"#{sid}", label="i.O.")
            for eid in ["erp_anlage","erp_schutz"]:
                page.select_option(f"#{eid}", label="i.O.")
            fill("erdung_re", "0,2")
            cards = page.locator("#circuitsContainer > *")
            for i in range(cards.count()):
                card = cards.nth(i)
                def cfill(sel, val):
                    loc = card.locator(sel)
                    if loc.count(): loc.first.fill(str(val))
                cfill(".c-bez", f"SK{i+1}")
                cfill(".c-rpe", "0,1")
                cfill(".c-riso", "> 500")
                cfill(".c-sich-typ", "B 16A")
                cfill(".c-zs", "0,3")
            page.select_option("#res_maengel", label="Keine Mängel festgestellt")
            page.select_option("#res_plakette", label="Ja")
            page.select_option("#res_gewaehrleistung", value="Ja")
            with page.expect_download() as dlw:
                page.click("text=Ausgefülltes PDF generieren")
            dlw.value.save_as(os.path.join(OUT, f"archivtest_protokoll_{idx+1}.pdf"))
            log(f"Protokoll {idx+1} erzeugt und archiviert")

        # ============ TEIL B: Archiv-Ansicht prüfen (Suche, Filter, Löschen, Vorlage) ============
        page.goto(f"{BASE}/archiv.html", wait_until="networkidle")
        page.wait_for_timeout(800)
        page.screenshot(path=os.path.join(OUT, "archiv_liste_screenshot.png"), full_page=True)

        # Suche testen
        search_box = page.locator("input[type=search], input#suche, input[placeholder*='Such']")
        if search_box.count():
            search_box.first.fill("Testanlage 2")
            page.wait_for_timeout(400)
            page.screenshot(path=os.path.join(OUT, "archiv_suche_screenshot.png"), full_page=True)
            search_box.first.fill("")
            page.wait_for_timeout(300)

        # XSS via Suchfeld
        if search_box.count():
            search_box.first.fill('<script>alert(1)</script>')
            page.wait_for_timeout(300)
            page.screenshot(path=os.path.join(OUT, "archiv_suche_xss_screenshot.png"), full_page=True)
            search_box.first.fill("")
            page.wait_for_timeout(300)

        # Zeile anklicken um Detail-Overlay zu öffnen, dann "Erneut prüfen (Vorlage)"
        row = page.locator(".archiv-zeile").first
        vorlage_btn = page.locator("#btnVorlage")
        if row.count():
            row.click()
            page.wait_for_timeout(400)
            page.screenshot(path=os.path.join(OUT, "archiv_detail_overlay_screenshot.png"), full_page=True)
        if vorlage_btn.count() and vorlage_btn.is_visible():
            log("'Erneut prüfen'-Button im Detail-Overlay sichtbar")
            vorlage_btn.click()
            page.wait_for_load_state("networkidle")
            page.wait_for_timeout(500)
            page.screenshot(path=os.path.join(OUT, "archiv_vorlage_uebernommen_screenshot.png"), full_page=True)
            # Prüfen: sind Messfelder wirklich leer?
            rpe_val = page.locator(".c-rpe").first.input_value() if page.locator(".c-rpe").count() else "N/A"
            bez_val = page.locator(".c-bez").first.input_value() if page.locator(".c-bez").count() else "N/A"
            sicht_val = page.locator("#sicht_betriebsmittel").input_value() if page.locator("#sicht_betriebsmittel").count() else "N/A"
            ergebnis_val = page.locator("#res_maengel").input_value() if page.locator("#res_maengel").count() else "N/A"
            auftraggeber_val = page.locator("#auftraggeber").input_value() if page.locator("#auftraggeber").count() else "N/A"
            log(f"VORLAGE-CHECK: auftraggeber (sollte uebernommen sein) = '{auftraggeber_val}'")
            log(f"VORLAGE-CHECK: c-rpe (sollte leer sein) = '{rpe_val}'")
            log(f"VORLAGE-CHECK: c-bez (sollte uebernommen sein) = '{bez_val}'")
            log(f"VORLAGE-CHECK: sicht_betriebsmittel (sollte i.O. Standardwert sein) = '{sicht_val}'")
            log(f"VORLAGE-CHECK: res_maengel (sollte leer sein) = '{ergebnis_val}'")
        else:
            log("KEIN 'Erneut pruefen'-Button gefunden!")

        # Löschen testen: Zeile anklicken -> Detail-Overlay -> "Aus Archiv löschen"
        page.goto(f"{BASE}/archiv.html", wait_until="networkidle")
        page.wait_for_timeout(600)
        before = page.locator(".archiv-zeile").count()
        row2 = page.locator(".archiv-zeile").first
        if row2.count():
            row2.click()
            page.wait_for_timeout(400)
            del_detail_btn = page.locator("text=Aus Archiv löschen")
            if del_detail_btn.count():
                del_detail_btn.first.click()
                page.wait_for_timeout(600)
        after = page.locator(".archiv-zeile").count()
        log(f"Vor Löschen: {before} Zeilen, nach Löschen: {after} Zeilen")
        page.screenshot(path=os.path.join(OUT, "archiv_nach_loeschen_screenshot.png"), full_page=True)

        # ============ TEIL C: Entwürfe / Autosave ============
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(300)
        fill("auftraggeber", "AUTOSAVE-TEST Firma")
        fill("anlage_bez", "AUTOSAVE-TEST Anlage")
        page.wait_for_timeout(1500)  # give autosave debounce time
        page.reload(wait_until="networkidle")
        page.wait_for_timeout(500)
        restored_auftraggeber = page.locator("#auftraggeber").input_value()
        restored_anlage = page.locator("#anlage_bez").input_value()
        log(f"AUTOSAVE-CHECK nach Reload: auftraggeber='{restored_auftraggeber}' anlage_bez='{restored_anlage}'")

        # Mehrere parallele Entwürfe: gehe zu index.html "Neues Formular", check "Offene Prüfungen"
        page.goto(f"{BASE}/index.html", wait_until="networkidle")
        page.wait_for_timeout(500)
        page.screenshot(path=os.path.join(OUT, "index_offene_pruefungen_screenshot.png"), full_page=True)
        offene = page.locator("text=Offene Prüfungen")
        log(f"'Offene Prüfungen' Sektion gefunden: {offene.count() > 0}")

        # ============ TEIL D: URL-Parameter-Manipulation ============
        page.goto(f"{BASE}/vde0100.html?entwurf=<script>alert(1)</script>", wait_until="networkidle")
        page.wait_for_timeout(500)
        page.screenshot(path=os.path.join(OUT, "urlparam_xss_screenshot.png"), full_page=True)
        log(f"URL nach Laden mit XSS-Param: {page.url}")

        page.goto(f"{BASE}/vde0100.html?entwurf=nonexistent-id-12345", wait_until="networkidle")
        page.wait_for_timeout(500)
        auftraggeber_nonexist = page.locator("#auftraggeber").input_value()
        log(f"Formular bei nicht existierendem Entwurf-Param: auftraggeber='{auftraggeber_nonexist}'")
        page.screenshot(path=os.path.join(OUT, "urlparam_nonexistent_screenshot.png"), full_page=True)

        # ============ TEIL E: Protokollnummer-Lücken-Test ============
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(300)
        nr_before = page.locator("#protokollnummer").input_value()
        log(f"Vorgeschlagene Nummer (vor Verbrauch): {nr_before}")
        # Klick auf "Neues Formular" (verbraucht Nummer), dann NICHT abschliessen -> neu laden
        neues_formular_btn = page.get_by_text("Neues Formular", exact=False)
        if neues_formular_btn.count():
            neues_formular_btn.first.click()
            page.wait_for_timeout(400)
            nr_after_neu = page.locator("#protokollnummer").input_value()
            log(f"Nummer nach 'Neues Formular': {nr_after_neu}")
        page.goto(f"{BASE}/vde0100.html", wait_until="networkidle")
        page.wait_for_timeout(300)
        nr_reload = page.locator("#protokollnummer").input_value()
        log(f"Vorgeschlagene Nummer nach Reload (Test auf Lücke): {nr_reload}")

        log(f"Console errors: {json.dumps(console_errors, ensure_ascii=False)}")
        with open(os.path.join(OUT, "archiv_entwuerfe_console_errors.json"), "w") as f:
            json.dump(console_errors, f, ensure_ascii=False, indent=2)
        browser.close()

if __name__ == "__main__":
    run()
