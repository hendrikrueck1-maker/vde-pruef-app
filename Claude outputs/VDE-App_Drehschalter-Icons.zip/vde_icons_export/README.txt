VDE-Prüf-App – Drehschalter-Icons für die Prüfkarten
=====================================================

Diese 6 Icons sind die "aktiven" Icons, die im Mockup verwendet werden
(je einmal pro Prüfgröße, RCD nutzt zwei davon nebeneinander):

  Z_S_Schleifenimpedanz-Kurzschlussstrom.png   → Karte "Z_S / I_K (Schleifenimpedanz)"
  RCD_Ausloesezeit_deltaT.png                  → Karte "RCD-Prüfung", linkes Icon (ΔT)
  RCD_Ausloesestrom_I_deltaN.png               → Karte "RCD-Prüfung", rechtes Icon (I_ΔN)
  R_ISO_Isolationswiderstand.png               → Karte "R_ISO (Isolationswiderstand)"
  R_PE_Schutzleiterwiderstand.png              → Karte "R_PE (Schutzleiterwiderstand)"
  U_L_Netzspannung.png                         → Karte "U_L / Netzspannung (Berührungsspannung)"

Ordner "unbenutzt/":
  Phase_unbenutzt.png, R_E_unbenutzt.png – zwei weitere Drehschalter-Positionen
  aus deinem Original-Screenshot, die aktuell bei keiner Prüfung im Formular
  gebraucht werden. Für den Fall, dass später eine passende Prüfung dazukommt,
  liegen sie hier bereit.

Format: PNG, ca. 160×160px, transparenter/kreisrunder Ausschnitt aus deinem
Original-Foto der Drehschalter-Skala. In der App werden sie als runde
40×40px-Badges dargestellt (object-fit: cover, border-radius: 50%) mit dem
jeweiligen Kurzlabel (Z_S, R_ISO, R_PE, U_L, ΔT, I_ΔN) direkt darunter.

Hinweis: Die schematischen "Drehschalter-Position"-Zeichnungen (SVG-Kreisdiagramme
mit Drehrichtungspfeil) sind bewusst NICHT enthalten – diese wurden auf deinen
Wunsch aus dem finalen Konzept gestrichen. Nur die reinen Foto-Icons werden
weiterverwendet.
