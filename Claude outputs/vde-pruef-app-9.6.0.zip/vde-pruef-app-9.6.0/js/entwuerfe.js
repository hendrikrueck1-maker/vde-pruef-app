/* ============================================================================
 *  OFFENE PRÜFUNGEN (MEHRERE PARALLELE ENTWÜRFE)
 * ----------------------------------------------------------------------------
 *  FRÜHER gab es je Formulartyp genau EINEN Autosave-Zwischenstand
 *  (localStorage-Key 'vde_autosave_pr' / '_ap' / '_gp'). Wer zwei
 *  Anschlussstellen gleichzeitig prüfte (z. B. Bühne links UND Bühne rechts),
 *  konnte immer nur an einer davon arbeiten - das Öffnen der zweiten
 *  überschrieb den Zwischenstand der ersten. Ein fertiges PDF landete zwar im
 *  Archiv, aber das Archiv speichert nur FERTIGE PDFs - ein angefangenes,
 *  noch nicht exportiertes Formular ließ sich dort nicht ablegen und später
 *  weiterbearbeiten.
 *
 *  JETZT: Jeder Formularstand ist ein eigener "Entwurf" mit eigener ID und
 *  eigenem Autosave-Key. Ein Index (DRAFTS_INDEX_KEY) verzeichnet alle
 *  offenen Entwürfe aller drei Formulartypen. Pro Formulartyp merkt sich die
 *  App zusätzlich, welcher Entwurf gerade "aktiv" ist (AKTIVER_ENTWURF_KEY) -
 *  das ist der, den ein normales erneutes Öffnen der Seite automatisch
 *  fortsetzt (bisheriges Autosave-Verhalten, jetzt nur pro Entwurf statt
 *  global).
 *
 *  Ein Entwurf bleibt bestehen, bis "Neues Formular anfordern" explizit
 *  einen neuen anlegt oder der Entwurf über die Liste "Offene Prüfungen"
 *  gelöscht wird. Ein PDF-Export SCHLIESST den Entwurf NICHT ab - das
 *  Formular bleibt bearbeitbar, ein erneuter Export ersetzt lediglich die
 *  zuvor heruntergeladene PDF-Datei (siehe pdf-utils.js savePdfCompatible).
 * ========================================================================== */

/* [9.2.0] WERKBANK-MODUS: wird von pruefschritte-uebersicht.html gesetzt,
 * wenn ein Formular dort in einem unsichtbaren iframe zum reinen
 * Feld-Test geladen wird (siehe dortiges <script> vor dem iframe-src).
 * Ohne diesen Schalter wuerde bereits das blosse OEFFNEN eines Formulars
 * einen echten Eintrag unter "Offene Prüfungen" anlegen (aktivenEntwurfSicherstellen
 * schreibt sofort in localStorage) - Testeingaben auf der Werkbank duerfen
 * aber niemals als echte Pruefung erscheinen oder eine echte gerade offene
 * Pruefung ueberschreiben. Im Werkbank-Modus bekommt jede Seite eine rein
 * fluechtige, NICHT in localStorage persistierte Entwurfs-ID; entwurfMerken()
 * (Eintrag in der Liste "Offene Prüfungen") wird komplett uebersprungen. */
var WERKBANK_MODUS = (function () {
  try { return window.top !== window.self && new URLSearchParams(location.search).get('werkbank') === '1'; }
  catch (e) { return false; }
})();

const DRAFTS_INDEX_KEY = 'vde_entwuerfe_index';

function aktiverEntwurfKey(praefix) {
  return 'vde_aktiver_entwurf_' + praefix;
}

function autosaveKeyFuerEntwurf(praefix, entwurfId) {
  return 'vde_autosave_' + praefix.toLowerCase() + '_' + entwurfId;
}

function ladeEntwuerfeIndex() {
  try {
    const raw = localStorage.getItem(DRAFTS_INDEX_KEY);
    const liste = raw ? JSON.parse(raw) : [];
    return Array.isArray(liste) ? liste : [];
  } catch (e) { return []; }
}

function speichereEntwuerfeIndex(liste) {
  // 5.0.0: sicherSetItem() (storage.js) statt direktem try/catch ohne
  // Meldung - ein voller Speicher wird jetzt sichtbar gemeldet statt still
  // zu scheitern (BUG #1 aus der 4.7.2-Prüfung).
  if (typeof sicherSetItem === 'function') {
    sicherSetItem(DRAFTS_INDEX_KEY, JSON.stringify(liste));
  } else {
    try { localStorage.setItem(DRAFTS_INDEX_KEY, JSON.stringify(liste)); } catch (e) {}
  }
}

/* 5.0.0 (BUG #7 aus der 4.7.2-Prüfung): ein monoton steigender Zaehler kommt
 * zum Zeitstempel+Zufallsteil hinzu. Vorher war eine Kollision zweier IDs
 * theoretisch moeglich, wenn zwei Entwuerfe in derselben Millisekunde UND
 * mit gleichem Zufallsteil angelegt wuerden - dann haette der zweite den
 * ersten im Index ueberschrieben. Der Zaehler macht das unabhaengig von
 * Zeitstempel und Zufall ausgeschlossen, ohne eine externe UUID-Bibliothek
 * zu benoetigen. */
let ENTWURF_ID_ZAEHLER = 0;

function neueEntwurfId() {
  ENTWURF_ID_ZAEHLER = (ENTWURF_ID_ZAEHLER + 1) % 1679616; // 36^4, bleibt kurz
  return Date.now().toString(36) + '-' + ENTWURF_ID_ZAEHLER.toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

/* Traegt einen Entwurf im Index ein oder aktualisiert seine Metadaten
 * (Bezeichnung, Protokollnummer, Zeitstempel) - aufgerufen bei jedem
 * Autosave, damit die Liste "Offene Prüfungen" immer aktuell ist. */
function entwurfMerken(praefix, entwurfId, meta) {
  if (WERKBANK_MODUS) return; // [9.2.0] Testeingaben landen nie in "Offene Prüfungen"
  const liste = ladeEntwuerfeIndex();
  const idx = liste.findIndex(e => e.id === entwurfId);
  // [7.2.0, Punkt 21] Ein bereits gesetztes "abgeschlossen"-Flag (per Checkbox
  // in der Liste "Offene Prüfungen" gesetzt) darf durch den naechsten
  // regulaeren Autosave-Aufruf aus dem Formular NICHT wieder zurueckgesetzt
  // werden - das Flag lebt ausschliesslich in der Liste, das Formular selbst
  // kennt es nicht. Deshalb wird ein vorhandener Wert hier uebernommen.
  const bisherigesFlag = idx !== -1 ? !!liste[idx].abgeschlossen : false;
  const eintrag = {
    id: entwurfId,
    praefix: praefix,
    protokollnummer: (meta && meta.protokollnummer) || '',
    bezeichnung: (meta && meta.bezeichnung) || '',
    // [8.0.0, Teil 6.4] Zusaetzlich zur bisherigen zusammengesetzten
    // "bezeichnung" (weiterhin fuer die Kachel-/Schnellzugriffs-Buttons auf
    // index.html genutzt) jetzt auch die Einzelteile separat, damit
    // renderOffenePruefungen() sie wie im Archiv einzeln/spaltenartig zeigen
    // kann (Standort, Gebäude/Bereich, Anlage, typspezifische Anzahl).
    standort: (meta && meta.standort) || '',
    gebaeude: (meta && meta.gebaeude) || '',
    anlage: (meta && meta.anlage) || '',
    anzahl: (meta && meta.anzahl) || 0,
    zuletzt: Date.now(),
    abgeschlossen: bisherigesFlag
  };
  if (idx === -1) liste.push(eintrag); else liste[idx] = eintrag;
  speichereEntwuerfeIndex(liste);
}

/* [7.2.0, Punkt 21] Setzt/entfernt das "IST ABGESCHLOSSEN"-Flag eines
 * Entwurfs. Anders als ein geloeschter Entwurf bleibt ein abgeschlossener
 * Entwurf vollstaendig erhalten (inkl. Autosave-Stand) und laesst sich
 * jederzeit wieder oeffnen/fortsetzen - das Flag dient nur der Uebersicht,
 * damit fertig bearbeitete, aber noch nicht als PDF exportierte Entwuerfe
 * nicht mehr zwischen den wirklich offenen Prüfungen stehen. */
function entwurfAbschlussUmschalten(entwurfId, abgeschlossen) {
  const liste = ladeEntwuerfeIndex();
  const idx = liste.findIndex(e => e.id === entwurfId);
  if (idx === -1) return;
  liste[idx].abgeschlossen = !!abgeschlossen;
  speichereEntwuerfeIndex(liste);
}

function entwurfEntfernen(entwurfId) {
  const liste = ladeEntwuerfeIndex().filter(e => e.id !== entwurfId);
  speichereEntwuerfeIndex(liste);
  const alle = { PR: null, AP: null, GP: null };
  Object.keys(alle).forEach(praefix => {
    try {
      const idx = localStorage.getItem(aktiverEntwurfKey(praefix));
      if (idx === entwurfId) localStorage.removeItem(aktiverEntwurfKey(praefix));
    } catch (e) {}
  });
}

function entwuerfeFuerTyp(praefix) {
  return ladeEntwuerfeIndex()
    .filter(e => e.praefix === praefix)
    .sort((a, b) => (b.zuletzt || 0) - (a.zuletzt || 0));
}

/* Liefert die ID des aktuell aktiven Entwurfs fuer einen Formulartyp und legt
 * beim allerersten Aufruf (kein aktiver Entwurf hinterlegt) automatisch einen
 * neuen an - inklusive Uebernahme eines eventuell noch vorhandenen alten,
 * globalen Autosave-Standes (Ruecksicht auf Nutzer, die von einer Version vor
 * 4.7.0 aktualisieren: ihr angefangenes Formular geht dabei nicht verloren). */
function aktivenEntwurfSicherstellen(praefix, altAutosaveKey) {
  // [9.2.0] Werkbank: fluechtige ID, NICHTS wird in localStorage geschrieben -
  // weder der "aktiver Entwurf"-Zeiger noch eine Migration eines Alt-Standes.
  if (WERKBANK_MODUS) return 'werkbank-' + praefix + '-' + Date.now();
  const key = aktiverEntwurfKey(praefix);
  let id;
  try { id = localStorage.getItem(key); } catch (e) { id = null; }

  if (id) return id;

  id = neueEntwurfId();
  try { sicherSetItem(key, id); } catch (e) {}

  // Migration: ein alter, formularweiter Autosave-Stand wird zum ersten Entwurf.
  // 5.0.0 (BUG #5 aus der 4.7.2-Prüfung): removeItem() steht jetzt in einem
  // eigenen try/catch NACH dem setItem, statt in derselben try-Klammer - so
  // wird der Alt-Key auch dann entfernt, wenn setItem am Ende doch fehlschlug
  // (z. B. Speicher wird erst zwischen den zwei Aufrufen voll). Vorher konnte
  // ein Fehler beim setItem verhindern, dass removeItem ueberhaupt erreicht
  // wird, wodurch der alte Key liegen blieb.
  if (altAutosaveKey) {
    let alt = null;
    try { alt = localStorage.getItem(altAutosaveKey); } catch (e) {}
    if (alt !== null) {
      sicherSetItem(autosaveKeyFuerEntwurf(praefix, id), alt);
      try { localStorage.removeItem(altAutosaveKey); } catch (e) {}
    }
  }
  return id;
}

function entwurfWechseln(praefix, entwurfId) {
  sicherSetItem(aktiverEntwurfKey(praefix), entwurfId);
}

/* Beim Aufruf einer Formularseite mit ?entwurf=<id> (Link aus der Liste
 * "Offene Prüfungen") wird dieser Entwurf sofort zum aktiven gemacht, BEVOR
 * aktivenEntwurfSicherstellen() greift - so oeffnet der Link direkt den
 * gewuenschten Zwischenstand statt des zuletzt aktiven.
 *
 * [Befund #4, Vollprüfungsbericht 6.1.0] Existiert die per URL angeforderte
 * ID nicht im Index (z. B. ein veralteter/kaputter Link, oder der Entwurf
 * wurde inzwischen geloescht/als PDF abgeschlossen), wurde bisher
 * stillschweigend ein neues, leeres Formular geoeffnet - fuer die Nutzerin
 * nicht von einem regulaeren "neuen Formular" zu unterscheiden. Jetzt wird
 * das per showNotification() sichtbar gemeldet, bevor auf ein neues/aktives
 * Formular ausgewichen wird. */
function entwurfAusUrlUebernehmen(praefix) {
  try {
    const params = new URLSearchParams(window.location.search);

    // [8.0.0, Teil 6.3] Grüner Button "Neues Protokoll" direkt in der
    // Protokolltyp-Kachel (index.html) verlinkt hierher mit "?neu=1" - legt
    // sofort und ohne Rueckfrage einen frischen, leeren Entwurf an und macht
    // ihn zum aktiven, BEVOR aktivenEntwurfSicherstellen() greift (die sonst
    // einfach den zuletzt aktiven Entwurf fortsetzen wuerde). Bewusst ohne
    // Bestaetigungsdialog: der Klick auf der Startseite ist bereits die
    // eindeutige, bewusste Nutzerentscheidung - anders als der bestehende
    // "+ Neues Formular"-Button MITTEN im Formular (neuesProtokoll() u.ae. in
    // storage.js/anschluss-generator.js/geraete-generator.js), der auch
    // unbeabsichtigt getroffen werden und laufende Eingaben verwerfen koennte.
    if (params.get('neu') === '1') {
      neuenEntwurfAnlegen(praefix); // legt an UND macht ihn zum aktiven Entwurf
      return;
    }

    const id = params.get('entwurf');
    if (!id) return;

    const existiert = ladeEntwuerfeIndex().some(e => e.id === id && e.praefix === praefix);
    if (existiert) {
      entwurfWechseln(praefix, id);
      return;
    }

    /* entwurfAusUrlUebernehmen() wird als Inline-Code ganz oben in
     * pdf-generator.js/anschluss-generator.js/geraete-generator.js
     * aufgerufen - diese <script>-Tags liegen im <head>, VOR <body>.
     * document.body existiert an dieser Stelle noch nicht, und
     * showNotification() (document.body.appendChild) wuerde deshalb
     * lautlos fehlschlagen (Exception, vom try/catch hier verschluckt).
     * Die Meldung wird deshalb auf DOMContentLoaded verschoben. */
    const melden = function () {
      if (typeof showNotification === 'function') {
        showNotification('Dieser Entwurf wurde nicht gefunden. Er wurde eventuell bereits abgeschlossen oder gelöscht - es wird stattdessen das zuletzt aktive bzw. ein neues Formular angezeigt.', 'error');
      }
    };
    if (document.body) {
      melden();
    } else {
      document.addEventListener('DOMContentLoaded', melden, { once: true });
    }
  } catch (e) {}
}

/* Legt einen frischen, leeren Entwurf an und macht ihn zum aktiven - fuer
 * "Neues Formular anfordern". Der bisherige Entwurf bleibt unangetastet im
 * Index stehen (er ist ja nicht abgeschlossen, nur nicht mehr aktiv offen). */
function neuenEntwurfAnlegen(praefix) {
  const id = neueEntwurfId();
  entwurfWechseln(praefix, id);
  return id;
}

function entwurfBezeichnung(praefix, fieldGetter) {
  // fieldGetter liefert { anlage, gebaeude, protokollnummer } je Formulartyp
  const f = fieldGetter ? fieldGetter() : {};
  const teile = [f.anlage, f.gebaeude].filter(Boolean);
  return teile.join(' – ') || (PROTOKOLL_PRAEFIXE[praefix] || praefix);
}

const ENTWURF_DATEI = { PR: 'vde0100.html', AP: 'anschlusspruefung.html', GP: 'geraetepruefung.html' };

/* [7.4.0, Punkt 6] Liefert den zuletzt bearbeiteten, NICHT abgeschlossenen
 * Entwurf ueber alle drei Protokolltypen hinweg (oder null, wenn es keinen
 * gibt) - Grundlage fuer den Button "Letztes weitermachen" auf index.html.
 * Bewusst dieselbe Datenquelle wie renderOffenePruefungen() (kein separater
 * Mechanismus), damit beide Stellen immer denselben Entwurf als "zuletzt"
 * ausweisen. */
function letzterOffenerEntwurf() {
  const alle = ['PR', 'AP', 'GP'].flatMap(entwuerfeFuerTyp).filter(e => !e.abgeschlossen);
  if (!alle.length) return null;
  alle.sort((a, b) => (b.zuletzt || 0) - (a.zuletzt || 0));
  return alle[0];
}

/* Rendert die Liste "Offene Prüfungen" in ein Container-Element (z. B. auf
 * index.html). Jede Zeile fuehrt per Link direkt zum betroffenen Formular
 * mit dem passenden ?entwurf=<id> - ein Klick oeffnet also GENAU diesen
 * Zwischenstand, nicht irgendeinen. */
function renderOffenePruefungen(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const alle = ['PR', 'AP', 'GP'].flatMap(entwuerfeFuerTyp);
  alle.sort((a, b) => (b.zuletzt || 0) - (a.zuletzt || 0));

  if (!alle.length) {
    el.innerHTML = '<p style="font-size:0.85rem; color:var(--secondary);">Keine offenen Prüfungen – jede neu gestartete Prüfung erscheint hier, solange sie nicht abgeschlossen wurde.</p>';
    return;
  }

  // [7.2.0, Punkt 21] Zwei Gruppen: wirklich offene Entwuerfe zuerst, fertig
  // bearbeitete ("IST ABGESCHLOSSEN" angehakt) danach unter eigener
  // Zwischenueberschrift - so faellt die eigentlich noch zu bearbeitende
  // Prüfung nicht mehr zwischen bereits erledigten unter, auch wenn diese
  // zuletzt bearbeitet wurden.
  const offen = alle.filter(e => !e.abgeschlossen);
  const abgeschlossen = alle.filter(e => e.abgeschlossen);

  function zeile(e) {
    /* [Befund #8, Vollprüfungsbericht 6.1.0] '#' als Fallback ergibt einen
     * Link, der auf der aktuellen Seite bleibt, statt auf ein gültiges
     * Formular zu verweisen. In der Praxis nicht erreichbar, da e.praefix
     * ausschließlich intern aus PROTOKOLL_PRAEFIXE gesetzt wird - trotzdem
     * ist 'index.html' ein sichereres Sicherheitsnetz, falls doch einmal ein
     * unbekanntes Präfix auftaucht. */
    const datei = ENTWURF_DATEI[e.praefix] || 'index.html';
    const typLabel = PROTOKOLL_PRAEFIXE[e.praefix] || e.praefix;
    const titel = e.protokollnummer ? (e.protokollnummer + (e.bezeichnung ? ' – ' + esc(e.bezeichnung) : '')) : esc(e.bezeichnung || typLabel);
    // [8.0.0, Teil 6.4] Zusatzzeile mit Standort/Gebäude/Bereich/Anlage sowie
    // typspezifischer Anzahl (Stromkreise/Geräte/Übergabepunkte) - analog zur
    // Sub-Zeile im Archiv (siehe archiv.html zeileBauen()). archivTyp() ist
    // schon vor dem ersten Aufruf von renderOffenePruefungen() geladen
    // (js/archiv.js wird auf index.html vor dem Inline-Skript eingebunden).
    const einheit = (typeof archivTyp === 'function') ? archivTyp(e.praefix).einheit : '';
    const zusatz = [e.standort, e.gebaeude, e.anlage, e.anzahl ? e.anzahl + ' ' + einheit : '']
      .filter(function (v, i, arr) { return v && arr.indexOf(v) === i; })
      .map(esc).join(' · ');
    return (
      '<div class="offene-pruefung-zeile' + (e.abgeschlossen ? ' ist-abgeschlossen' : '') + '">' +
        '<div class="offene-pruefung-info">' +
          '<span class="offene-pruefung-typ">' + esc(typLabel) + '</span>' +
          '<strong>' + titel + '</strong>' +
          (zusatz ? '<span class="offene-pruefung-zusatz">' + zusatz + '</span>' : '') +
          '<span class="offene-pruefung-zeit">zuletzt bearbeitet ' + formatZuletzt(e.zuletzt) + '</span>' +
          '<label class="offene-pruefung-abschluss">' +
            '<input type="checkbox"' + (e.abgeschlossen ? ' checked' : '') +
            ' onchange="entwurfAbschlussUmschalten(\'' + attrEsc(e.id) + '\', this.checked); renderOffenePruefungen(\'' + attrEsc(containerId) + '\');">' +
            ' IST ABGESCHLOSSEN' +
          '</label>' +
        '</div>' +
        '<div class="offene-pruefung-aktionen">' +
          '<a class="btn btn-success" href="' + datei + '?entwurf=' + encodeURIComponent(e.id) + '">Öffnen</a>' +
          '<button type="button" class="btn-danger" onclick="offenePruefungLoeschen(\'' + attrEsc(e.id) + '\', \'' + attrEsc(e.praefix) + '\')">Löschen</button>' +
        '</div>' +
      '</div>'
    );
  }

  // [Nutzerwunsch] Offene Prüfungen jetzt genau wie die abgeschlossenen in
  // einem eigenen <details>-Element einklappbar - anders als dort aber
  // standardmaessig AUFGEKLAPPT ("open"), damit sich am gewohnten
  // Erscheinungsbild beim Aufrufen der Startseite nichts aendert. Der
  // Zustand wird - wie bei "Abgeschlossen" - bewusst NICHT sitzungsweit
  // gemerkt und startet bei jedem Aufruf wieder aufgeklappt.
  let offenInhalt = offen.map(zeile).join('');
  if (!offen.length) {
    offenInhalt = '<p style="font-size:0.85rem; color:var(--secondary);">Keine wirklich offenen Prüfungen mehr – alle sind als abgeschlossen markiert.</p>';
  }
  let html = '<details class="offene-pruefungen-details" open>' +
    '<summary class="offene-pruefungen-titel">Offene Prüfungen (' + offen.length + ')</summary>' +
    offenInhalt +
  '</details>';
  if (abgeschlossen.length) {
    // [7.3.0, Nutzerwunsch #6] Abgeschlossene Pruefungen jetzt in einem
    // eigenen, standardmaessig EINGEKLAPPTEN <details>-Element statt
    // dauerhaft sichtbar unter einer Zwischenueberschrift - bei vielen
    // abgeschlossenen Entwuerfen bleibt die Liste "Offene Prüfungen" so
    // uebersichtlich. Der offen-Zustand wird bewusst NICHT sitzungsweit
    // gemerkt (anders als die Mess-Infokarten) - die Liste soll bei jedem
    // Aufruf der Startseite wieder eingeklappt starten, das ist hier der
    // sinnvolle Normalzustand.
    html += '<details class="offene-pruefungen-abgeschlossen-details">' +
      '<summary class="offene-pruefungen-abgeschlossen-titel">Abgeschlossen, aber noch nicht als PDF archiviert (' + abgeschlossen.length + ')</summary>' +
      abgeschlossen.map(zeile).join('') +
    '</details>';
  }
  el.innerHTML = html;
}

/* 5.0.0 (BUG #9 aus der 4.7.2-Prüfung): escapt jetzt auch " und ' - vorher
 * fehlte das, obwohl esc() auch innerhalb von HTML-Attributen verwendet wird
 * (z. B. onclick="offenePruefungLoeschen('...')" oben in renderOffenePruefungen).
 * In der Praxis bestehen Entwurf-IDs und Präfixe nur aus Base36-Zeichen bzw.
 * PR/AP/GP, ein Anführungszeichen konnte dort also nicht auftreten - aber
 * esc() wird auch auf freien Text (Bezeichnung) angewendet, und ein
 * ungeschütztes " in einem HTML-Attribut ist grundsätzlich unsicher designt. */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

async function offenePruefungLoeschen(entwurfId, praefix) {
  if (!await appConfirm('Diese offene Prüfung endgültig löschen? Ein noch nicht als PDF gespeicherter Zwischenstand geht dabei verloren.')) return;
  entwurfEntfernen(entwurfId);
  try { localStorage.removeItem(autosaveKeyFuerEntwurf(praefix, entwurfId)); } catch (e) {}
  if (typeof renderOffenePruefungen === 'function') renderOffenePruefungen('offenePruefungenListe');
}

function formatZuletzt(ts) {
  if (!ts) return '';
  const diffMin = Math.round((Date.now() - ts) / 60000);
  if (diffMin < 1) return 'gerade eben';
  if (diffMin < 60) return 'vor ' + diffMin + ' Min.';
  const diffStd = Math.round(diffMin / 60);
  if (diffStd < 24) return 'vor ' + diffStd + ' Std.';
  const d = new Date(ts);
  return d.toLocaleDateString('de-DE') + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}
