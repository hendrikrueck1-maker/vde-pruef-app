/* ============================================================================
 *  STATUS-KOPFLEISTE
 * ----------------------------------------------------------------------------
 *  Zeigt jederzeit sichtbar: Anlage/Gebäude/Bezeichnung sowie eine
 *  Orientierung, in welchem ABSCHNITT des Gesamtprotokolls man sich gerade
 *  befindet - z. B. "Stammdaten" ganz am Anfang, "Stromkreis 3 von 12"
 *  waehrend man Kreise/Geraete/Zuleitungen bearbeitet, oder
 *  "Gesamtbewertung" gegen Ende. Ohne diese Leiste war bei einem langen
 *  Formular mit vielen Karten nach dem Scrollen nicht mehr auf den ersten
 *  Blick zu sehen, wo man sich gerade befindet.
 *
 *  6.2.0 (Feature E): Die Prüfprotokollnummer wurde aus der Leiste entfernt -
 *  sie bleibt ein ganz normales Formularfeld, ist aber nicht mehr staendig
 *  sichtbar. Stattdessen zeigt die Leiste jetzt zusaetzlich die grobe
 *  Abschnitts-Position im GESAMTEN Formular, nicht nur "Stromkreis X von Y"
 *  waehrend man in den Karten ist: davor z. B. "Stammdaten", danach z. B.
 *  "Gesamtbewertung" - ueber cfg.abschnitte (siehe initStatusleiste-Aufruf
 *  in vde0100.html/anschlusspruefung.html/geraetepruefung.html), da die drei
 *  Formulare unterschiedliche Abschnittsfolgen haben.
 *
 *  4.7.1: Die Karten-Anzeige folgt jetzt nicht mehr nur dem Tastaturfokus
 *  (Klick/Tab in ein Feld), sondern zusaetzlich einem IntersectionObserver,
 *  der beim reinen Scrollen erkennt, welche Karte bzw. welcher Abschnitt
 *  gerade oben im sichtbaren Bereich steht - man sieht also jederzeit, "wo
 *  man ist", auch ohne irgendein Feld anzuklicken.
 *
 *  initStatusleiste(cfg) wird von jeder Formularseite mit ihren eigenen
 *  Feld-IDs und ihrem Karten-/Abschnitts-Selektor aufgerufen - siehe Aufruf
 *  am Ende von vde0100.html / anschlusspruefung.html / geraetepruefung.html.
 * ========================================================================== */
function initStatusleiste(cfg) {
  const leiste = document.createElement('div');
  leiste.className = 'status-leiste';
  leiste.innerHTML =
    '<span class="sl-typ">' + (cfg.typLabel || '') + '</span>' +
    '<span class="sl-trenner" id="sl_trenner_bez">·</span>' +
    '<span class="sl-bez" id="sl_bez"></span>' +
    '<span class="sl-kreis" id="sl_kreis"></span>';

  const form = document.querySelector('form') || document.body;
  form.parentNode.insertBefore(leiste, form);

  const bezEl = leiste.querySelector('#sl_bez');
  const trennerBezEl = leiste.querySelector('#sl_trenner_bez');
  const kreisEl = leiste.querySelector('#sl_kreis');

  function aktualisiereKopf() {
    const teile = (cfg.bezFeldIds || []).map(id => (document.getElementById(id)?.value || '').trim()).filter(Boolean);
    const bez = teile.join(' – ');
    bezEl.textContent = bez;
    trennerBezEl.style.display = bez ? '' : 'none';
  }

  // [7.2.0, Nutzerwunsch #17] Zusaetzlich zur laufenden Nummer ("Stromkreis
  // #3") auch die vom Nutzer eingetragene Bezeichnung/Zweck der Karte
  // (.c-bez, z. B. "Schukosteckdose Tonregie") in der Statusleiste anzeigen -
  // das war bisher nur in der Karte selbst sichtbar, nicht mehr, sobald man
  // innerhalb der Karte nach unten zu den Messwerten gescrollt/fokussiert
  // hatte.
  function kartenBezeichnung(karte) {
    const bezEl = karte.querySelector('.c-bez');
    const bez = bezEl ? String(bezEl.value || '').trim() : '';
    return bez;
  }

  function aktualisiereKreis(ziel) {
    if (!cfg.kartenSelector) return;
    const karte = ziel && ziel.closest ? ziel.closest(cfg.kartenSelector) : null;
    if (!karte) return; // Fokus ausserhalb einer Karte -> letzten Stand stehen lassen
    const label = karte.querySelector(cfg.kartenLabelSelector || '.circuit-header span, .feed-header span, .card-header span');
    const nummer = label ? label.textContent.trim() : '';
    const bez = kartenBezeichnung(karte);
    kreisEl.textContent = bez ? (nummer + ' – ' + bez) : nummer;
    kreisEl.dataset.quelle = 'karte';
    kreisEl.dataset.aktuelleKarte = ''; // wird unten gesetzt, falls Karte ein Element ist
    if (karte.id) kreisEl.dataset.aktuelleKarte = karte.id;
  }

  // Die Bezeichnung kann sich AENDERN, waehrend die Statusleiste bereits auf
  // dieser Karte steht (Nutzer tippt gerade ins .c-bez-Feld selbst) - ohne
  // diesen Listener wuerde die Leiste erst beim naechsten Kartenwechsel
  // nachziehen. 'input' bubbelt, ein einzelner document-weiter Listener
  // deckt daher alle Karten/Formulare ab.
  document.addEventListener('input', function (ev) {
    if (!ev.target || !ev.target.classList || !ev.target.classList.contains('c-bez')) return;
    if (kreisEl.dataset.quelle !== 'karte') return;
    const karte = cfg.kartenSelector ? ev.target.closest(cfg.kartenSelector) : null;
    if (!karte || !karte.id || karte.id !== kreisEl.dataset.aktuelleKarte) return;
    aktualisiereKreis(ev.target);
  });

  /* ABSCHNITTS-ORIENTIERUNG (6.2.0, Feature E)
   * ---------------------------------------------------------------------
   * cfg.abschnitte: Liste von { selector, label }, in Reihenfolge des
   * jeweiligen Formulars (die drei Formulare haben unterschiedliche
   * Abschnittsfolgen, siehe initStatusleiste-Aufruf pro Formularseite).
   * "selector" zeigt auf die <h2>-Ueberschrift jedes Abschnitts. Bei jedem
   * Scroll-Ereignis wird neu bestimmt, welche Ueberschrift den oberen Rand
   * des sichtbaren Bereichs zuletzt ueberschritten hat - das ist der
   * "aktuelle Abschnitt" (Details siehe abschnittNeuBerechnen() unten).
   * Zeigt die Leiste gerade eine konkrete Karte (Stromkreis/Geraet/
   * Zuleitung) an, hat diese Anzeige Vorrang - der Abschnittsname erscheint
   * nur ausserhalb von Karten. */
  let aktuellerAbschnitt = '';
  function abschnittAnzeigenFallsKeineKarte() {
    if (kreisEl.dataset.quelle === 'karte' && kreisEl.textContent) return;
    kreisEl.textContent = aktuellerAbschnitt;
    kreisEl.dataset.quelle = 'abschnitt';
  }

  /* [7.1.0 Bugfix "Statusleiste funktioniert nicht richtig"]
   * ---------------------------------------------------------------------
   * BEFUND: Nach einmaligem Kartenfokus/-sichtbarkeit (quelle === 'karte')
   * blieb die Leiste bei reinem Scrollen (v. a. bei einem einzelnen groben
   * Sprung wie scrollTo()/scrollIntoView() statt vieler kleiner Wheel-
   * Events) dauerhaft auf der zuletzt gezeigten Karte haengen, obwohl man
   * laengst in einem ganz anderen Abschnitt war (z. B. "Gesamtbewertung").
   * URSACHE: Der IntersectionObserver meldet nur GRENZUEBERGAENGE
   * (isIntersecting wechselt true/false). Landet ein Sprung-Scroll direkt
   * auf einer Position, an der bereits (wie zuvor) keine Karte im schmalen
   * Beobachtungsstreifen liegt, gibt es dort keinen erneuten Uebergang -
   * der Observer feuert schlicht nicht erneut, und die alte 'karte'-Quelle
   * blieb faelschlich stehen. abschnittNeuBerechnen() (die bei JEDEM
   * Scroll-Event laeuft, nicht nur bei Grenzuebergaengen) prueft deshalb
   * hier zusaetzlich aktiv nach, ob die aktuell als "quelle=karte"
   * gefuehrte Karte ueberhaupt noch in der Naehe des sichtbaren Bereichs
   * liegt - falls nicht, wird die Quelle zurueckgesetzt, damit der
   * Abschnittsname wieder greifen kann. */
  function karteNochImBlick() {
    if (kreisEl.dataset.quelle !== 'karte') return true; // nichts zu pruefen
    if (!cfg.kartenSelector) return true;
    const karten = document.querySelectorAll(cfg.kartenSelector);
    for (const karte of karten) {
      const top = karte.getBoundingClientRect().top;
      const bottom = karte.getBoundingClientRect().bottom;
      // Grosszuegiger Toleranzbereich um den Viewport - reicht, um eine
      // Karte als "noch relevant" zu werten, ohne so eng zu sein wie der
      // IntersectionObserver-Streifen (der ja gerade das Problem ist).
      if (bottom >= -100 && top <= window.innerHeight + 100) return true;
    }
    return false;
  }

  if (Array.isArray(cfg.abschnitte) && cfg.abschnitte.length) {
    const eintraege = cfg.abschnitte
      .map(a => ({ el: document.querySelector(a.selector), label: a.label }))
      .filter(a => a.el);

    if (eintraege.length) {
      /* Von allen Abschnitts-Ueberschriften diejenige bestimmen, die den
       * oberen Rand (knapp unter der fixen Leiste) zuletzt ueberschritten
       * hat - das ist der "aktuelle" Abschnitt. Bewusst als einfache
       * Neuberechnung ueber ALLE Ueberschriften bei jedem Scroll-Ereignis
       * statt per IntersectionObserver-Delta: bei kurzen Formularen (wenige
       * Karten, z. B. Anschlusspruefung/Geraetepruefung mit nur 1-2 Karten)
       * liegen mehrere Ueberschriften nah beieinander und ein einzelner
       * grosser Scroll-Sprung (scrollIntoView(), schnelles Wischen) kann
       * mehrere davon in einem Schritt "uebergehen", ohne dass der
       * IntersectionObserver fuer jede einzelne ein eigenes
       * Sichtbarkeits-Wechsel-Ereignis liefert. Die Neuberechnung ist
       * bewusst billig (ein paar getBoundingClientRect()-Aufrufe) und wird
       * per requestAnimationFrame entprellt. */
      function abschnittNeuBerechnen() {
        // Ganz nach unten gescrollt (Ende des Formulars erreicht): der
        // letzte Abschnitt gilt immer, auch wenn dessen Ueberschrift wegen
        // wenig Restinhalt darunter (kurzes Formular, z. B. Anschluss-/
        // Geraeteprüfung mit nur 1-2 Karten) rechnerisch nie ueber die
        // Schwelle hinausscrollt.
        // Steht die Anzeige noch auf einer Karte, die laengst nicht mehr in
        // Sichtweite ist (siehe Kommentar bei karteNochImBlick oben), die
        // Quelle zuruecksetzen, DAMIT die folgenden Zweige den Abschnitts-
        // namen ueberhaupt zeigen duerfen.
        if (!karteNochImBlick()) kreisEl.dataset.quelle = '';

        const amEnde = (window.innerHeight + window.scrollY) >= (document.documentElement.scrollHeight - 2);
        if (amEnde) {
          aktuellerAbschnitt = eintraege[eintraege.length - 1].label;
          abschnittAnzeigenFallsKeineKarte();
          return;
        }
        let aktuelle = eintraege[0];
        eintraege.forEach(function (eintrag) {
          if (eintrag.el.getBoundingClientRect().top <= 56) aktuelle = eintrag;
        });
        aktuellerAbschnitt = aktuelle.label;
        abschnittAnzeigenFallsKeineKarte();
      }

      let abschnittTicking = false;
      function abschnittTaktPlanen() {
        if (abschnittTicking) return;
        abschnittTicking = true;
        requestAnimationFrame(function () {
          abschnittNeuBerechnen();
          abschnittTicking = false;
        });
      }
      window.addEventListener('scroll', abschnittTaktPlanen, { passive: true });
      window.addEventListener('resize', abschnittTaktPlanen);

      // Anfangszustand direkt berechnen, bevor ueberhaupt gescrollt wurde.
      abschnittNeuBerechnen();
    }
  }

  // Sobald der Fokus eine Karte verlaesst (z. B. Klick in ein Stammdaten-Feld
  // nach vorherigem Kartenfokus), soll wieder der Abschnittsname greifen
  // statt der zuletzt angezeigten Karte.
  function aktualisiereKreisOderAbschnitt(ziel) {
    if (cfg.kartenSelector) {
      const karte = ziel && ziel.closest ? ziel.closest(cfg.kartenSelector) : null;
      if (karte) { aktualisiereKreis(ziel); return; }
    }
    kreisEl.dataset.quelle = '';
    abschnittAnzeigenFallsKeineKarte();
  }

  aktualisiereKopf();
  document.addEventListener('input', aktualisiereKopf);
  document.addEventListener('change', aktualisiereKopf);
  document.addEventListener('focusin', function (ev) { aktualisiereKreisOderAbschnitt(ev.target); });

  /* 6.2.0: Im Stromkreis-Karussell (vde0100.html) findet Navigation oft per
   * Wisch-/Pfeil-Geste statt, OHNE dass dabei ein Feld fokussiert wird - der
   * obige IntersectionObserver greift hier nicht zuverlaessig (er geht von
   * vertikalem Seitenscroll aus, das Karussell scrollt aber horizontal
   * innerhalb eines eigenen, schmalen Containers). js/karussell.js feuert
   * deshalb bei jedem Kartenwechsel ein 'vde:karussell-wechsel'-Event mit der
   * neu aktiven Karte im 'detail' - hier einfach denselben Kreis-Anzeige-Pfad
   * wie beim Fokuswechsel nutzen. */
  document.addEventListener('vde:karussell-wechsel', function (ev) {
    if (ev.detail && ev.detail.karte) aktualisiereKreis(ev.detail.karte);
  });

  /* [Nutzerwunsch] STATUSLEISTE VERSCHWINDET BEI GEOEFFNETER BILDSCHIRMTASTATUR
   * --------------------------------------------------------------------------
   *  "position: sticky" (siehe style.css) haelt die Leiste zuverlaessig oben,
   *  SOLANGE Layout- und sichtbarer (visueller) Bereich beim Scrollen
   *  gemeinsam wandern. Oeffnet sich auf einem Smartphone/Tablet die
   *  Bildschirmtastatur, verschieben iOS Safari und (je nach Geraet/Version)
   *  auch mobile Chrome-Varianten den TATSAECHLICH SICHTBAREN Ausschnitt
   *  (visualViewport) unabhaengig vom Scroll-Stand des Layout-Viewports nach
   *  oben, um das fokussierte Feld oberhalb der Tastatur einzublenden - der
   *  Scroll-Stand, auf den sich "sticky"/"fixed" beziehen, aendert sich dabei
   *  NICHT mit. Die Leiste bleibt also an ihrer Position im Layout-Viewport
   *  stehen, waehrend genau dieser Bereich durch die Tastatur-Verschiebung
   *  nicht mehr im sichtbaren Ausschnitt liegt - sie wirkt dadurch wie
   *  verschwunden, obwohl sie technisch weiterhin vorhanden ist.
   *
   *  Die window.visualViewport-API (breit unterstuetzt: iOS Safari ab 13,
   *  Chrome/Android seit Jahren) liefert genau diesen Versatz als
   *  "offsetTop". Ein einfaches translateY() um diesen Betrag gleicht ihn
   *  aus und haelt die Leiste exakt am oberen Rand des tatsaechlich
   *  sichtbaren Bereichs - beim normalen Scrollen (Tastatur geschlossen)
   *  bleibt offsetTop 0 und die Leiste verhaelt sich unveraendert wie zuvor. */
  if (window.visualViewport) {
    const vv = window.visualViewport;
    let taktGeplant = false;
    function statusleisteAnSichtbarenBereichAnpassen() {
      taktGeplant = false;
      leiste.style.transform = vv.offsetTop ? 'translateY(' + vv.offsetTop + 'px)' : '';
    }
    function taktPlanen() {
      // rAF buendelt mehrere schnell aufeinanderfolgende resize/scroll-
      // Ereignisse (z. B. waehrend der Tastatur-Einblendanimation) zu einem
      // Layout-Update statt bei jedem einzelnen Ereignis neu zu rechnen.
      if (taktGeplant) return;
      taktGeplant = true;
      requestAnimationFrame(statusleisteAnSichtbarenBereichAnpassen);
    }
    vv.addEventListener('resize', taktPlanen);
    vv.addEventListener('scroll', taktPlanen);
  }

  /* Beim reinen Scrollen (ohne Klick/Fokus in ein Feld) soll die Anzeige
   * ebenfalls folgen: ein IntersectionObserver beobachtet alle Karten und
   * merkt sich, welche davon gerade den sichtbaren Bereich unmittelbar unter
   * der Statusleiste kreuzt. rootMargin schneidet den Beobachtungsstreifen
   * auf einen schmalen Bereich knapp unterhalb der (fixen) Leiste zusammen -
   * dadurch zaehlt die Karte, die man gerade tatsaechlich vor Augen hat,
   * nicht irgendeine, die nur teilweise unten ins Bild ragt. */
  /* 6.2.1 Bugfix: Direkt nach dem Registrieren feuert ein neuer
   * IntersectionObserver fuer jede bereits im Beobachtungsstreifen
   * sichtbare Karte sofort ein erstes "isIntersecting"-Ereignis - auch beim
   * blossen Laden der Seite, ganz ohne dass der Nutzer gescrollt, geklickt
   * oder gewischt hat. Ohne Absicherung ueberschreibt das den korrekt
   * berechneten Anfangszustand ("Stammdaten") faelschlich mit der ersten
   * Karte ("Stromkreis 1"). Analog zur bestehenden eventMelden-Absicherung
   * in js/karussell.js wird deshalb das ERSTE Ereignis jeder (Neu-)Registrierung
   * verworfen, wenn der Nutzer bis dahin noch nicht aktiv gescrollt/fokussiert
   * hat - kartenBeobachtungAktiv wird erst nach der ersten echten Nutzer-
   * Interaktion (Scroll, Fokus) auf true gesetzt. */
  let kartenBeobachtungAktiv = false;
  function nutzerInteraktionMelden() { kartenBeobachtungAktiv = true; }
  window.addEventListener('scroll', nutzerInteraktionMelden, { passive: true, once: true });
  document.addEventListener('focusin', nutzerInteraktionMelden, { once: true });
  document.addEventListener('wheel', nutzerInteraktionMelden, { passive: true, once: true });
  document.addEventListener('touchmove', nutzerInteraktionMelden, { passive: true, once: true });

  let sichtbarkeitsObserver = null;
  function kartenBeobachten() {
    if (!cfg.kartenSelector) return;
    if (!('IntersectionObserver' in window)) return;
    if (sichtbarkeitsObserver) sichtbarkeitsObserver.disconnect();
    let erstesEreignisDieserRegistrierung = true;
    sichtbarkeitsObserver = new IntersectionObserver(function (entries) {
      // Das allererste Ereignis nach (Neu-)Registrierung ignorieren, solange
      // der Nutzer noch nicht aktiv interagiert hat (siehe Kommentar oben) -
      // verhindert das faelschliche "Stromkreis 1" direkt nach dem Laden.
      if (erstesEreignisDieserRegistrierung) {
        erstesEreignisDieserRegistrierung = false;
        if (!kartenBeobachtungAktiv) return;
      }
      // Von allen gerade im Beobachtungsstreifen sichtbaren Karten die oberste
      // (kleinster Abstand von oben) als "aktuelle" Karte uebernehmen.
      let beste = null;
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        if (!beste || entry.boundingClientRect.top < beste.boundingClientRect.top) beste = entry;
      });
      if (beste) {
        aktualisiereKreis(beste.target);
      } else {
        // Keine Karte mehr im Beobachtungsstreifen sichtbar (6.2.0, Feature E):
        // man hat den Kartenbereich beim Scrollen bereits verlassen (nach oben
        // in die Stammdaten oder nach unten in die Gesamtbewertung) - dann soll
        // wieder der Abschnittsname greifen statt der zuletzt gezeigten Karte.
        kreisEl.dataset.quelle = '';
        abschnittAnzeigenFallsKeineKarte();
      }
    }, { root: null, rootMargin: '-56px 0px -70% 0px', threshold: 0 });
    document.querySelectorAll(cfg.kartenSelector).forEach(function (karte) {
      sichtbarkeitsObserver.observe(karte);
    });
  }
  kartenBeobachten();

  // Nach jedem Hinzufuegen/Entfernen/Wiederherstellen von Karten kann sich die
  // Zuordnung geaendert haben - MutationObserver haelt die Anzeige aktuell,
  // auch wenn kein Fokuswechsel stattfindet (z. B. nach addCircuitCard()), und
  // sorgt dafuer, dass neue/entfernte Karten auch vom Scroll-Beobachter oben
  // wieder korrekt erfasst werden.
  if (cfg.kartenContainerSelector) {
    const container = document.querySelector(cfg.kartenContainerSelector);
    if (container) {
      const obs = new MutationObserver(function () {
        if (document.activeElement) aktualisiereKreis(document.activeElement);
        kartenBeobachten();
      });
      obs.observe(container, { childList: true });
    }
  }
}
